**Message:**

**PCI DSS Requirement 8 – Identification and Authentication**
===========================================================

### 8.1 Processes and Mechanisms

#### 8.1.1
All security policies and operational procedures for identification and authentication are:
- Documented
- Kept up to date
- In use
- Known to all affected parties

**Control Mapping:**

* Documented: AWS Organizations, AWS IAM, AWS CloudTrail
* Kept up to date: AWS IAM, AWS CloudFormation
* In use: AWS IAM, AWS Cognito
* Known to all affected parties: AWS IAM, AWS Organizations, AWS CloudFormation

**Narrative Guidance for Engineers:**

* Ensure that security policies and operational procedures for identification and authentication are stored in AWS Organizations, AWS IAM, and AWS CloudFormation.
* Regularly review and update these policies and procedures to ensure they remain current and effective.
* Ensure that all affected parties are aware of and understand these policies and procedures.

### 8.2 User Identification

#### 8.2.1
All users are uniquely identified before access to system components.

**Control Mapping:**

* Uniquely identified: AWS IAM, AWS Cognito
* AWS IAM Users: AWS IAM
* AWS Cognito Users: AWS Cognito

**Narrative Guidance for Engineers:**

* Ensure that all users are uniquely identified using AWS IAM or AWS Cognito before accessing system components.
* Use AWS IAM to manage unique user identities and access permissions.
* Use AWS Cognito to manage unique user identities and access permissions for web and mobile applications.

#### 8.2.2
Group, shared, or generic IDs are not used unless explicitly approved.

**Control Mapping:**

* AWS IAM Groups: AWS IAM
* AWS Cognito Groups: AWS Cognito

**Narrative Guidance for Engineers:**

* Avoid using group, shared, or generic IDs unless explicitly approved by management.
* Use AWS IAM Groups or AWS Cognito Groups to manage access permissions for groups of users.
* Ensure that group membership is regularly reviewed and updated to ensure that access permissions remain current and effective.

### 8.3 Strong Authentication

#### 8.3.1
Multi-factor authentication (MFA) is implemented for all access into the CDE.

**Control Mapping:**

* AWS IAM MFA: AWS IAM
* AWS Cognito MFA: AWS Cognito

**Narrative Guidance for Engineers:**

* Implement MFA for all access into the CDE using AWS IAM or AWS Cognito.
* Use AWS IAM MFA to require MFA for AWS IAM users.
* Use AWS Cognito MFA to require MFA for AWS Cognito users.

#### 8.3.2
MFA is enforced for all remote access.

**Control Mapping:**

* AWS IAM MFA: AWS IAM
* AWS Cognito MFA: AWS Cognito

**Narrative Guidance for Engineers:**

* Enforce MFA for all remote access using AWS IAM or AWS Cognito.
* Use AWS IAM MFA to require MFA for remote access to AWS IAM users.
* Use AWS Cognito MFA to require MFA for remote access to AWS Cognito users.

#### 8.3.3
MFA mechanisms must not be bypassable.

**Control Mapping:**

* AWS IAM MFA: AWS IAM
* AWS Cognito MFA: AWS Cognito

**Narrative Guidance for Engineers:**

* Ensure that MFA mechanisms are not bypassable using AWS IAM or AWS Cognito.
* Use AWS IAM MFA to require MFA for AWS IAM users and prevent bypassing.
* Use AWS Cognito MFA to require MFA for AWS Cognito users and prevent bypassing.

### Testing Procedures (Simplified)

* Verify MFA is enabled for all IAM users
* Verify root account MFA is enabled
* Check authentication logs for MFA usage

**Control Mapping:**

* AWS IAM MFA: AWS IAM
* AWS Cognito MFA: AWS Cognito
* AWS CloudTrail: AWS CloudTrail

**Narrative Guidance for Engineers:**

* Verify that MFA is enabled for all IAM users using AWS IAM.
* Verify that the root account MFA is enabled using AWS IAM.
* Use AWS CloudTrail to check authentication logs for MFA usage.