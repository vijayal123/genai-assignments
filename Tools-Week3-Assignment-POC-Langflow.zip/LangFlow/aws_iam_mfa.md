# AWS Context – Requirement 8 (MFA)

## Services

- AWS IAM
- AWS IAM Identity Center
- AWS CloudTrail

---

## Key Configurations

### IAM Users
- MFA enabled for all users
- Console login requires MFA

### Root Account
- MFA must be enabled
- Hardware MFA preferred

### IAM Identity Center
- Enforce MFA for all users
- Integrate with IdP if applicable

---

## Evidence Required

- IAM user MFA status report
- Root account MFA proof
- CloudTrail logs showing MFA authentication events
- IAM policy enforcing MFA conditions

---

## Example Evidence Commands

- aws iam get-account-summary
- aws iam list-virtual-mfa-devices
- CloudTrail event: ConsoleLogin with MFAUsed = Yes
