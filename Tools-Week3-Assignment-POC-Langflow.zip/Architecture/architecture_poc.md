# architecture_poc.md

# 🛡️ PCI DSS Documentation Assistant POC Architecture

---

## 1. 🚀 Executive Summary & Problem Statement

PCI DSS documentation is manual, repetitive, and error-prone.

### Core Pain Points

- 📚 Document explosion across multiple requirements
- 🧩 Context gaps between PCI text and cloud implementation
- 🕵️ Manual evidence collection across AWS services
- ❌ Human interpretation errors during policy writing
- 🔁 Rework during QSA audit cycles

### POC Objective

This POC isolates document generation from infrastructure access.

It de-risks automation by focusing only on:

- Controlled input (PCI DSS text)
- Deterministic output (policy markdown templates)

No live AWS interaction is allowed.

This ensures safety, traceability, and audit confidence.

---

## 2. 🧭 System Scope & Boundaries

### Input Scope

- PCI DSS 4.0.1 Requirement 5 (Malware)
- PCI DSS 4.0.1 Requirement 8 (MFA)
- PCI DSS 4.0.1 Requirement 10 (Logging)

### Output Scope

- Structured Markdown policy documents
- Embedded “Narrative Guidance for Engineers”
- Evidence-focused instructions for audit readiness

### Explicit Boundaries

- 🛑 No real-time AWS API calls
- 🛑 No infrastructure mutation
- 🛑 No autonomous agent execution
- ✅ Read-only document generation

---

### AWS Mapping by Requirement

#### Requirement 5 – Malware Protection

- AWS Systems Manager (SSM)
- SSM Anti-Malware Extensions
- Amazon GuardDuty

#### Requirement 8 – MFA Enforcement

- AWS IAM
- AWS IAM Identity Center
- Root account MFA enforcement

#### Requirement 10 – Logging & Monitoring

- AWS CloudTrail
- Amazon CloudWatch
- Amazon S3 (log archive + retention policies)

---

## 3. 🏗️ Component Architecture

### Repository Structure

```
pci-dss-doc-assistant/
│
├── data/
│   ├── pci_requirements/
│   │   ├── req_5.txt
│   │   ├── req_8.txt
│   │   └── req_10.txt
│   │
│   └── aws_context/
│       ├── iam.md
│       ├── cloudtrail.md
│       ├── guardduty.md
│
├── prompts/
│   ├── system_prompt.md
│   └── narrative_rules.md
│
├── engine/
│   ├── orchestrator.py
│   ├── rag_loader.py
│   ├── llm_client.py
│   └── template_builder.py
│
├── output/
│   ├── policy_req_5.md
│   ├── policy_req_8.md
│   └── policy_req_10.md
│
└── architecture_poc.md
```

---

### Data Flow Sequence

```mermaid
sequenceDiagram
    participant User
    participant RawFiles as Raw Requirement Files
    participant AWSVars as AWS Service Context
    participant RAG as Local RAG Loader
    participant LLM as LLM Processing Layer
    participant Output as Markdown Generator

    User->>RawFiles: Select Requirement (5,8,10)
    User->>AWSVars: Provide AWS Context Files

    RawFiles->>RAG: Load PCI DSS Text
    AWSVars->>RAG: Load AWS Mapping Context

    RAG->>LLM: Inject Context + System Prompt

    LLM->>Output: Generate Policy Template
    Output->>User: Deliver Markdown Document
```



---

## 4. 📊 System Instructions & Trusted Reference Data

### Hallucination Prevention Strategy

The AI must not invent compliance statements.

Strict controls are enforced:

- 📌 Only PCI DSS text is treated as truth
- 📌 AWS mappings are predefined and static
- 📌 No external knowledge injection allowed

---

### Trusted Data Sources

- Official PCI DSS 4.0.1 requirement text
- Curated AWS service configuration notes

These are stored locally and version-controlled.

---

### AI Behavioral Rules

The system prompt enforces:

- Act as PCI DSS compliance auditor
- Use formal, policy-grade language
- Do not assume missing controls
- Always map requirement → AWS evidence

---

### Narrative Guidance Enforcement

Each section must include:

**Narrative Guidance for Engineers**

This block must:

- Specify exact AWS evidence required
- Define log locations and configurations
- Highlight audit artifacts for QSA review

---

### Why Small Context Improves Accuracy

- Smaller inputs reduce ambiguity
- Improves deterministic output
- Limits hallucination surface area
- Enhances audit traceability

---

## ✅ POC Outcome

- Reliable PCI DSS policy draft generation
- Engineer-ready narrative guidance
- Audit-aligned documentation structure
- Safe foundation for future automation expansion

---

## 🔮 Future Evolution (Post-POC)

- Controlled AWS read-only integrations
- Evidence auto-collection pipelines
- Continuous compliance validation engine
- QSA-ready reporting dashboards

---

