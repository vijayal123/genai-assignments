# Batch Resume Ingestion Utility — Design & Implementation Plan

> **Project:** `resume-ai-rag2`  
> **Tech Stack:** Node.js · TypeScript · Express · MongoDB Atlas · Mistral Embeddings · Winston Logger  
> **Purpose:** Add a standalone CLI utility that reads PDF resumes from a folder, processes them in configurable batches using the **existing ingestion pipeline**, pauses after each batch for user confirmation, and reports results with full structured logging.

---

## 1. Utility Overview

### What it does

```
Run utility via CLI
       ↓
Read BATCH_SIZE from .env (default: 5, max: 10)
       ↓
Pick up to BATCH_SIZE PDF files from /Resumes folder
       ↓
For each file → call existing ResumeIngestionService.injectResume()
       ↓
Success? → Move file to /ProcessedResumes
Failure? → Move file to /QuarantinedFiles + write <filename>.error
       ↓
Log Batch Summary
       ↓
More files remaining?
  YES → Ask user: "Continue with next batch? (yes/no)"
          ├── yes → pick next batch and repeat
          └── no  → exit gracefully with final summary
  NO  → Print "No more files to process" and exit
```

### Key Design Decisions

| Decision | Choice | Reason |
|---|---|---|
| Run style | Standalone CLI script | Does not disturb the running Express server |
| Pipeline reuse | Calls existing `ResumeIngestionService.injectResume()` directly | No duplication of logic |
| Logger reuse | Uses existing `initializeConfig()` → `createLogger()` + `createIngestionLogger()` | Consistent structured logs |
| MongoDB reuse | Uses existing `connectMongoDB()` / `getDatabase()` | No new DB config needed |
| Config reuse | Uses existing `loadConfig()` for all env vars | Single source of truth |
| New env vars | Only `BATCH_SIZE` added | Minimal footprint |
| **Interactive prompt** | **Ask yes/no after each batch if more files remain** | **Gives operator control without fully automating** |

---

## 2. Recommended Design

### Processing Flow

```
CLI Command: npx ts-node src/batch/batchIngest.ts
                     │
           ┌─────────▼─────────┐
           │  Load .env config  │  (loadConfig + createLogger)
           │  Connect MongoDB   │
           └─────────┬─────────┘
                     │
           ┌─────────▼─────────┐
           │  BatchFolderManager│  Scan /Resumes, read BATCH_SIZE files
           └─────────┬─────────┘
                     │
              ┌──────┴──────┐
              │  Any files?  │
              └──────┬──────┘
          YES ↓              ↓ NO
    ┌──────────────┐    "No more files
    │ Process Batch │     to process"
    └──────┬───────┘          │ EXIT
           │
    ┌──────▼───────────────────────────────────┐
    │  For each file in batch (sequential):     │
    │  1. Validate file (PDF + size check)      │
    │  2. Call ResumeIngestionService           │
    │     .injectResume(filePath, fileName)     │
    │  3. On SUCCESS → move to /ProcessedResumes│
    │  4. On FAILURE → move to /QuarantinedFiles│
    │               → write <filename>.error    │
    └──────┬───────────────────────────────────┘
           │
    ┌──────▼────────┐
    │  Log Batch    │  BatchLogger emits batch_summary log
    │  Summary      │  (shows processed / failed / skipped count)
    └──────┬────────┘
           │
    ┌──────▼──────────────┐
    │  More files left?    │
    └──────┬──────────────┘
           │ YES                          NO ↓
           ↓                    "No more files to process"
    ┌──────▼──────────────────────────┐        │ EXIT
    │  BatchPromptHandler              │
    │  "Continue with next batch?"     │
    │  Waiting for user input...       │
    └──────┬──────────────────────────┘
           │
      ┌────┴────┐
      │  Input?  │
      └────┬────┘
    yes ↓      ↓ no / any other input
  Next Batch   "Batch run stopped by user"
               Log final summary → EXIT
```

---

## 3. Suggested Folder Structure

Only **new files** are shown. Existing files are unchanged.

```
resume-ai-rag2/
│
├── .env                             ← ADD: BATCH_SIZE=5
│
├── Resumes/                         ← NEW: Drop PDF files here
├── ProcessedResumes/                ← NEW: Successfully ingested files land here
├── QuarantinedFiles/                ← NEW: Failed files + .error logs land here
│
└── src/
    └── batch/                       ← NEW: Entire batch utility lives here
        │
        ├── batchIngest.ts           ← NEW: CLI entry point (run this)
        │
        ├── BatchOrchestrator.ts     ← NEW: Drives the loop — read → process → prompt → repeat
        │
        ├── BatchFolderManager.ts    ← NEW: Read/move files across the three folders
        │
        ├── BatchFileValidator.ts    ← NEW: Validate each file before processing
        │
        ├── BatchPromptHandler.ts    ← NEW: Interactive yes/no prompt between batches
        │
        └── BatchLogger.ts           ← NEW: Wraps existing IngestionLogger for batch events
```

> **No changes** are needed to any existing file in `src/ingestion/`, `src/config/`, `src/services/`, or `src/routes/`.

---

## 4. File Responsibilities

### 4.1 `Resumes/` folder
- **Purpose:** Input queue. Drop all PDF resumes here before running the utility.  
- **Contents:** Only `.pdf` files. Other file types are quarantined automatically.  
- **Auto-created:** If missing, the utility creates it on startup.

---

### 4.2 `ProcessedResumes/` folder
- **Purpose:** Archive of successfully ingested resumes.  
- **Contents:** The original PDF, moved here after successful MongoDB insertion.  
- **Naming:** File names are preserved as-is.  
- **Auto-created:** If missing, the utility creates it on startup.

---

### 4.3 `QuarantinedFiles/` folder
- **Purpose:** Holds failed or invalid files with their error reports.  
- **Contents (per failed file):**
  - `<originalfilename>.pdf` — the original file moved here
  - `<originalfilename>.error` — plain text error report (see Error Handling section)
- **Auto-created:** If missing, the utility creates it on startup.

---

### 4.4 `src/batch/batchIngest.ts` — CLI Entry Point

**Responsibility:** Bootstrap and kick off the batch run.

```
Responsibilities:
  - Load dotenv (.env + .env.local)
  - Call initializeConfig() to get config + winston logger
  - Call connectMongoDB() to establish DB connection
  - Instantiate BatchOrchestrator
  - Call orchestrator.run()
  - On finish: print summary, disconnect MongoDB, exit(0)
  - On uncaught error: log + exit(1)
```

**This is the ONLY file you run from the command line.**

---

### 4.5 `src/batch/BatchOrchestrator.ts` — Main Loop Driver

**Responsibility:** Drive the full batch loop with interactive confirmation between batches.

```
Responsibilities:
  - Read BATCH_SIZE from .env (default: 5, cap at 10)
  - Call BatchFolderManager.getNextBatch(batchSize) to get a list of files
  - If no files at start → log "No more files to process" → return
  - For each file in the batch (SEQUENTIAL, not parallel):
      → call BatchFileValidator.validate(filePath)
      → call ResumeIngestionService.injectResume(filePath, fileName, requestId)
      → on success: call BatchFolderManager.moveToProcessed(filePath)
      → on failure: call BatchFolderManager.moveToQuarantined(filePath, error)
  - After each batch: emit batch summary log via BatchLogger
  - Check if more files remain in /Resumes
  - If YES → call BatchPromptHandler.askContinue()
      → if user answers "yes" → continue loop
      → if user answers "no"  → log "Batch run stopped by user" → break loop
  - If NO  → log "No more files to process" → break loop
  - After loop ends: emit final run summary via BatchLogger
```

**Why sequential (not parallel)?**
- Mistral Embedding API has rate limits. Parallel calls risk hitting those limits.
- Sequential processing is simpler to debug and log.
- The existing `ResumeIngestionService` is not designed for concurrency.

---

### 4.6 `src/batch/BatchPromptHandler.ts` ← **NEW** — Interactive Prompt

**Responsibility:** Pause execution between batches and read a yes/no answer from the terminal.

```
Methods:

  askContinue(batchNumber, remainingCount): Promise<boolean>
    → Print to console:
        ─────────────────────────────────────────────
        Batch #<batchNumber> complete.
        Files remaining in Resumes/: <remainingCount>
        Continue with next batch? (yes/no):
        ─────────────────────────────────────────────
    → Open readline interface on process.stdin / process.stdout
    → Wait for user to type and press Enter
    → Normalize input: trim + lowercase
    → If input is "yes" or "y"  → resolve(true)
    → If input is "no"  or "n"  → resolve(false)
    → If input is anything else  → print "Please type yes or no" and re-prompt
    → Close readline interface after answer is received

  close(): void
    → Cleanly close the readline interface (called on exit)
```

**Key behaviours:**
- Re-prompts until a valid `yes`/`no` (`y`/`n`) answer is received — no silent failures.
- Uses Node.js built-in `readline` module — **no new npm packages needed**.
- The prompt is printed directly to `process.stdout` so it is always visible even if Winston is redirected to a file.

---

### 4.7 `src/batch/BatchFolderManager.ts` — File System Manager

**Responsibility:** All file system operations for the three folders.

```
Methods:
  ensureFoldersExist()
    → Create Resumes/, ProcessedResumes/, QuarantinedFiles/ if missing

  getNextBatch(batchSize: number): string[]
    → List all .pdf files in Resumes/
    → Return first batchSize file paths (sorted by name for determinism)

  getRemainingCount(): number
    → Count all .pdf files currently in Resumes/ (used for the prompt message)

  moveToProcessed(filePath: string): void
    → Move file from Resumes/ → ProcessedResumes/
    → If a file with same name already exists in ProcessedResumes/:
        append a timestamp to avoid overwrite (e.g., resume_20240530_143022.pdf)

  moveToQuarantined(filePath: string, error: Error): void
    → Move file from Resumes/ → QuarantinedFiles/
    → Write <filename>.error text file alongside it in QuarantinedFiles/

  writeErrorFile(fileName: string, errorContent: string): void
    → Creates QuarantinedFiles/<filename>.error with structured error content

  buildErrorContent(fileName, batchNumber, fileIndex, batchSize, phase, error, partialTimings): string
    → Assemble the formatted error report string (see Error File Format in Section 6)
```

---

### 4.8 `src/batch/BatchFileValidator.ts` — Pre-Processing Validator

**Responsibility:** Validate a file before handing it to the ingestion pipeline.

```
Validations (in order):
  1. File exists on disk                  → Error: "File not found"
  2. Extension is .pdf (case-insensitive) → Error: "Invalid file type. Only PDF allowed"
  3. File size > 0 bytes                  → Error: "File is empty"
  4. File size ≤ 5 MB                     → Error: "File exceeds 5MB size limit"

Returns: { valid: true } or throws a descriptive Error
```

> If validation fails → the file is immediately moved to QuarantinedFiles without calling the ingestion pipeline. This protects Mistral API quota.

---

### 4.9 `src/batch/BatchLogger.ts` — Batch-Level Logging

**Responsibility:** Emit structured batch-level log entries using the existing Winston logger.

```
Log events emitted:
  batch_run_start          → { batchSize, totalFilesInFolder }
  batch_start              → { batchNumber, filesInBatch: [filenames] }
  batch_file_success       → { fileName, insertedId, totalMs }
  batch_file_skipped       → { fileName, reason: "validation failed", error }
  batch_file_error         → { fileName, phase, error }
  batch_complete           → { batchNumber, processed, failed, skipped, remainingFiles }
  batch_user_stopped       → { stoppedAfterBatch: batchNumber }        ← NEW
  batch_run_complete       → { totalBatches, totalProcessed, totalFailed, totalSkipped, totalMs }
  batch_no_files           → { message: "No more files to process" }
```

> For per-file pipeline logs (extract, parse, embed, store steps),  
> the **existing `IngestionLogger`** already handles those automatically  
> via `ResumeIngestionService`. No duplication needed.

---

## 5. Running the Utility

### Prerequisites
- The Express server does **not** need to be running. This is a completely standalone CLI.
- MongoDB must be reachable (same `.env` connection string is used).
- PDF files must be placed in the `Resumes/` folder.
- The terminal must be interactive (stdin must be connected) so the yes/no prompt can receive input.

---

### Step 1 — Configure `.env`

Add the following to your existing `.env` file:

```env
# Batch Ingestion Configuration
BATCH_SIZE=5
```

> - Default: `5` if not set  
> - Maximum enforced by code: `10`  
> - Setting `BATCH_SIZE=15` will be silently capped to `10` with a warning log

---

### Step 2 — Place PDF files

```
resume-ai-rag2/
└── Resumes/
    ├── alice_resume.pdf
    ├── bob_resume.pdf
    ├── charlie_resume.pdf
    ...
```

---

### Step 3 — Run the utility

**Development (TypeScript, using ts-node):**

```bash
npx ts-node src/batch/batchIngest.ts
```

**Production (after building with `npm run build`):**

```bash
node dist/src/batch/batchIngest.js
```

**Add as an npm script in `package.json` (recommended):**

```json
"scripts": {
  "batch:ingest": "ts-node src/batch/batchIngest.ts"
}
```

Then simply run:

```bash
npm run batch:ingest
```

---

### Sample Console Output

```
2024-05-30 14:30:00.123 [info] batch_run_start { batchSize: 5, totalFilesInFolder: 12 }
2024-05-30 14:30:00.150 [info] batch_start { batchNumber: 1, filesInBatch: ["alice.pdf","bob.pdf","charlie.pdf","david.pdf","eve.pdf"] }

2024-05-30 14:30:00.200 [info] ingestion_pipeline_start { requestId: "batch-1-1", fileName: "alice.pdf" }
2024-05-30 14:30:02.800 [info] ingestion_pipeline_summary { requestId: "batch-1-1", fileName: "alice.pdf", extractMs: 180, parseMs: 90, embeddingMs: 1800, mongoInsertMs: 110, totalMs: 2600 }
2024-05-30 14:30:02.850 [info] batch_file_success { fileName: "alice.pdf", insertedId: "665...", totalMs: 2600 }

2024-05-30 14:30:03.000 [info] ingestion_pipeline_start { requestId: "batch-1-2", fileName: "bob.pdf" }
2024-05-30 14:30:03.100 [error] ingestion_pipeline_error { requestId: "batch-1-2", fileName: "bob.pdf", failedAt: "embed", error: "Mistral API timeout" }
2024-05-30 14:30:03.110 [error] batch_file_error { fileName: "bob.pdf", phase: "embed", error: "Mistral API timeout" }

... (charlie.pdf, david.pdf, eve.pdf processed) ...

2024-05-30 14:30:15.000 [info] batch_complete { batchNumber: 1, processed: 4, failed: 1, skipped: 0, remainingFiles: 7 }

─────────────────────────────────────────────────────
Batch #1 complete.
  ✔ Processed : 4
  ✘ Failed    : 1
  ⊘ Skipped   : 0
Files remaining in Resumes/: 7
Continue with next batch? (yes/no): yes
─────────────────────────────────────────────────────

2024-05-30 14:30:18.200 [info] batch_start { batchNumber: 2, filesInBatch: ["frank.pdf",...] }

... (batch 2 processed) ...

2024-05-30 14:31:00.000 [info] batch_complete { batchNumber: 2, processed: 5, failed: 0, skipped: 0, remainingFiles: 2 }

─────────────────────────────────────────────────────
Batch #2 complete.
  ✔ Processed : 5
  ✘ Failed    : 0
  ⊘ Skipped   : 0
Files remaining in Resumes/: 2
Continue with next batch? (yes/no): no
─────────────────────────────────────────────────────

2024-05-30 14:31:01.000 [info] batch_user_stopped { stoppedAfterBatch: 2 }
2024-05-30 14:31:01.010 [info] batch_run_complete { totalBatches: 2, totalProcessed: 9, totalFailed: 1, totalSkipped: 0, totalMs: 61000 }

═══════════════════════════════════════════════════════
 BATCH RUN COMPLETE — Stopped by user after batch #2
═══════════════════════════════════════════════════════
 Total Batches Run : 2
 Total Processed   : 9
 Total Failed      : 1
 Total Skipped     : 0
 Files Remaining   : 2  (still in Resumes/)
 Total Duration    : 61s
═══════════════════════════════════════════════════════
```

> **Note:** When user types `no`, the 2 remaining files are **left untouched** in `Resumes/`. They will be picked up the next time the utility is run.

---

## 6. Error Handling

### Error Classification

| Scenario | Where it fails | Action |
|---|---|---|
| Not a PDF file | BatchFileValidator | Quarantine immediately, skip pipeline |
| File empty (0 bytes) | BatchFileValidator | Quarantine immediately, skip pipeline |
| File > 5MB | BatchFileValidator | Quarantine immediately, skip pipeline |
| PDF text extraction fails | Phase 3 (ResumeParserService) | Quarantine after pipeline throws |
| Text is blank after cleaning | Phase 4 (TextCleanerService) | Quarantine after pipeline throws |
| Mistral API timeout/failure | Phase 9 (EmbeddingService) | Quarantine after pipeline throws |
| MongoDB insert failure | Phase 10 (ResumeIngestionRepository) | Quarantine after pipeline throws |
| File system I/O error (move fails) | BatchFolderManager | Log error, continue next file |
| User types invalid input at prompt | BatchPromptHandler | Re-prompt until valid yes/no received |

---

### Error File Format

For every failed file, a `<filename>.error` is created in `QuarantinedFiles/`:

**Example:** `QuarantinedFiles/bob_resume.error`

```
====================================================
 BATCH INGESTION ERROR REPORT
====================================================
File Name   : bob_resume.pdf
Date/Time   : 2024-05-30T14:30:03.110Z
Batch Number: 1
File Index  : 2 of 5

FAILURE PHASE : embed
ERROR TYPE    : MistralApiError
ERROR MESSAGE : Request timed out after 10000ms

STACK TRACE:
  Error: Request timed out after 10000ms
    at EmbeddingService.generateEmbedding (src/ingestion/services/EmbeddingService.ts:87:15)
    at ResumeIngestionService.injectResume (src/ingestion/services/ResumeIngestionService.ts:122:34)
    at BatchOrchestrator.processFile (src/batch/BatchOrchestrator.ts:78:22)

PARTIAL TIMINGS (steps completed before failure):
  extractMs : 180ms
  cleanMs   : 12ms
  parseMs   : 90ms
  embeddingMs: (failed)

ACTION TAKEN: File moved to QuarantinedFiles/
====================================================
```

---

### Duplicate File Name in ProcessedResumes

If a file with the same name was already processed previously:

```
alice_resume.pdf  →  alice_resume_20240530_143022.pdf
```

This prevents silent overwrites and preserves all copies.

---

## 7. Implementation Plan

Follow these steps in order. Each step is self-contained.

---

### Step 1 — Add BATCH_SIZE to `.env`

**File:** `.env`  
**Change:** Add one line

```env
BATCH_SIZE=5
```

No changes to `src/config/index.ts` are needed — the utility reads this directly via `process.env.BATCH_SIZE`.

---

### Step 2 — Create the three working folders

Create these empty folders at the project root (same level as `src/`):

```
Resumes/
ProcessedResumes/
QuarantinedFiles/
```

Add a `.gitkeep` file inside each so Git tracks them. Add the contents to `.gitignore`:

```gitignore
# Batch ingestion folders (content should not be committed)
Resumes/*.pdf
ProcessedResumes/
QuarantinedFiles/
```

---

### Step 3 — Create `src/batch/` folder

Create the folder. All new files go here.

---

### Step 4 — Implement `BatchLogger.ts`

**Location:** `src/batch/BatchLogger.ts`  
**Purpose:** Structured batch-level log methods  
**Depends on:** Winston `Logger` (already available via `initializeConfig()`)

Implement the following log methods:
- `logBatchRunStart(batchSize, totalFiles)`
- `logBatchStart(batchNumber, fileNames[])`
- `logFileSuccess(fileName, insertedId, totalMs)`
- `logFileError(fileName, phase, error)`
- `logFileSkipped(fileName, reason, error)`
- `logBatchComplete(batchNumber, processed, failed, skipped, remainingFiles)`
- `logUserStopped(stoppedAfterBatch)` ← **NEW**
- `logBatchRunComplete(totalBatches, totalProcessed, totalFailed, totalSkipped, totalMs)`
- `logNoMoreFiles()`

> Pattern: Follow the same pattern as `src/ingestion/utils/ingestionLogger.ts`. Each method calls `this.logger.info(event_name, { ...fields })`.

---

### Step 5 — Implement `BatchPromptHandler.ts` ← **NEW STEP**

**Location:** `src/batch/BatchPromptHandler.ts`  
**Purpose:** Interactive yes/no prompt between batches  
**Depends on:** Node.js built-in `readline` module (no new npm package)

Implement the following:

```
class BatchPromptHandler:

  private rl: readline.Interface
    → Created once in constructor
    → readline.createInterface({ input: process.stdin, output: process.stdout })

  askContinue(batchNumber: number, remainingCount: number): Promise<boolean>
    → Print a formatted batch summary banner to console:
        ─────────────────────────────────────────────
        Batch #<batchNumber> complete.
        Files remaining in Resumes/: <remainingCount>
        Continue with next batch? (yes/no):
        ─────────────────────────────────────────────
    → Use rl.question() to wait for user input
    → Normalize: input.trim().toLowerCase()
    → If "yes" or "y"  → resolve true
    → If "no"  or "n"  → resolve false
    → Else             → print "Invalid input. Please type yes or no." and re-ask (recursive call)

  close(): void
    → Call rl.close() to release stdin
    → Must be called by BatchOrchestrator after the run loop ends
```

**Important:** `rl.close()` must always be called at the end of `BatchOrchestrator.run()` — even if the run exits early — to prevent the process from hanging.

---

### Step 6 — Implement `BatchFileValidator.ts`

**Location:** `src/batch/BatchFileValidator.ts`  
**Purpose:** Validate each PDF before ingestion  
**Depends on:** Node.js built-in `fs`, `path`

Validation rules (throw `Error` with a descriptive message if invalid):

1. File must exist (`fs.existsSync`)
2. Extension must be `.pdf` (use `path.extname`)
3. File size must be > 0 bytes (`fs.statSync`)
4. File size must be ≤ 5 × 1024 × 1024 bytes (5 MB)

---

### Step 7 — Implement `BatchFolderManager.ts`

**Location:** `src/batch/BatchFolderManager.ts`  
**Purpose:** All file system operations  
**Depends on:** Node.js built-in `fs`, `path`

Implement these methods:

```
ensureFoldersExist()
  → fs.mkdirSync for Resumes/, ProcessedResumes/, QuarantinedFiles/ with { recursive: true }

getNextBatch(batchSize): string[]
  → fs.readdirSync('Resumes/')
  → filter to only .pdf files
  → sort alphabetically
  → slice(0, batchSize)
  → return full paths

getRemainingCount(): number                ← NEW
  → fs.readdirSync('Resumes/')
  → filter to .pdf files
  → return count

moveToProcessed(fileName: string): void
  → Build source path: Resumes/<fileName>
  → Build dest path: ProcessedResumes/<fileName>
  → If dest already exists: rename to <name>_<timestamp><ext>
  → fs.renameSync(source, dest)

moveToQuarantined(fileName: string): void
  → Build source path: Resumes/<fileName>
  → Build dest path: QuarantinedFiles/<fileName>
  → fs.renameSync(source, dest)

writeErrorFile(fileName: string, errorContent: string): void
  → Build error file path: QuarantinedFiles/<fileName>.error
  → fs.writeFileSync(errorPath, errorContent, 'utf8')

buildErrorContent(fileName, batchNumber, fileIndex, batchSize, phase, error, partialTimings): string
  → Assemble the formatted error report string (see Error File Format in Section 6)
```

---

### Step 8 — Implement `BatchOrchestrator.ts`

**Location:** `src/batch/BatchOrchestrator.ts`  
**Purpose:** Main processing loop with interactive confirmation  
**Depends on:** `BatchFolderManager`, `BatchFileValidator`, `BatchLogger`, `BatchPromptHandler`, `ResumeIngestionService`

Logic:

```
constructor(logger, config)
  → create BatchFolderManager, BatchFileValidator, BatchLogger, BatchPromptHandler
  → create ResumeIngestionService(logger)   ← existing class, no changes
  → read batchSize = Math.min(parseInt(process.env.BATCH_SIZE || '5'), 10)
  → if batchSize < 1: warn + set to 1

async run()
  → folderManager.ensureFoldersExist()
  → totalFiles = folderManager.getRemainingCount()
  → batchLogger.logBatchRunStart(batchSize, totalFiles)
  → batchNumber = 0
  → totalProcessed = 0, totalFailed = 0, totalSkipped = 0

  → LOOP:
      batch = folderManager.getNextBatch(batchSize)
      if batch is empty:
        batchLogger.logNoMoreFiles()
        BREAK

      batchNumber++
      batchLogger.logBatchStart(batchNumber, batch)

      for each file in batch (await — sequential):
          fileName = path.basename(file)
          requestId = `batch-${batchNumber}-${index+1}`

          try:
            validator.validate(file)              ← throws if invalid
            result = await ingestionService.injectResume(file, fileName, requestId)
            folderManager.moveToProcessed(fileName)
            batchLogger.logFileSuccess(fileName, result.insertedId, result.processingMs.totalMs)
            totalProcessed++

          catch (error):
            phase = determinePhase(error)
            errorContent = folderManager.buildErrorContent(...)
            folderManager.moveToQuarantined(fileName)
            folderManager.writeErrorFile(fileName, errorContent)
            batchLogger.logFileError(fileName, phase, error)
            totalFailed++

      remainingCount = folderManager.getRemainingCount()
      batchLogger.logBatchComplete(batchNumber, batchProcessed, batchFailed, batchSkipped, remainingCount)

      ── INTERACTIVE CONFIRMATION ────────────────────────────
      if remainingCount > 0:
        userWantsContinue = await promptHandler.askContinue(batchNumber, remainingCount)
        if NOT userWantsContinue:
          batchLogger.logUserStopped(batchNumber)
          BREAK
      ────────────────────────────────────────────────────────

  → promptHandler.close()          ← ALWAYS close readline, even on early exit
  → batchLogger.logBatchRunComplete(totalBatches, totalProcessed, totalFailed, totalSkipped, totalMs)
  → print final summary banner to console
```

---

### Step 9 — Implement `batchIngest.ts` (CLI Entry Point)

**Location:** `src/batch/batchIngest.ts`  
**Purpose:** Bootstrap and start the batch run  
**Depends on:** `initializeConfig`, `connectMongoDB`, `BatchOrchestrator`

```
async main():
  1. Load dotenv (.env.local, .env)
  2. const { config, logger } = initializeConfig()
  3. await connectMongoDB(config, logger)
  4. const orchestrator = new BatchOrchestrator(logger, config)
  5. await orchestrator.run()
  6. await disconnectMongoDB(logger)
  7. process.exit(0)

catch(error):
  console.error('Batch ingestion failed:', error)
  process.exit(1)

main()
```

---

### Step 10 — Add npm script to `package.json`

**File:** `package.json`  
**Change:** Add to `scripts` section:

```json
"batch:ingest": "ts-node src/batch/batchIngest.ts"
```

This allows the utility to be run as:

```bash
npm run batch:ingest
```

---

### Step 11 — Manual Test Plan

Run through these scenarios **before** declaring done:

| Test Case | Steps | Expected |
|---|---|---|
| Happy path — continue yes | Put 12 PDFs, BATCH_SIZE=5, type "yes" at each prompt | All 3 batches run (5+5+2), all processed |
| Stop after batch 1 — type no | Put 12 PDFs, BATCH_SIZE=5, type "no" at first prompt | Only first 5 processed; 7 files remain in Resumes/ |
| Accept "y" shorthand | Type "y" at prompt | Treated as yes, continues |
| Accept "n" shorthand | Type "n" at prompt | Treated as no, exits |
| Invalid input then valid | Type "maybe", then "yes" | Re-prompts once, then continues |
| No files at start | Empty Resumes/ folder | Logs "No more files to process", no prompt shown, exits 0 |
| Exactly one batch worth | Put 5 PDFs, BATCH_SIZE=5 | All 5 processed, no prompt shown (no remaining files), exits 0 |
| Invalid file type | Put .docx in Resumes/ | Quarantined, .error created, prompt still shown if other files remain |
| Oversized file | Put PDF > 5MB | Quarantined, .error created |
| API failure (simulate) | Set invalid MISTRAL_API_KEY | File quarantined, .error has API error detail |
| Duplicate name | Run same file twice | Second copy renamed with timestamp in ProcessedResumes/ |
| BATCH_SIZE=15 in .env | Set BATCH_SIZE=15 | Capped to 10 with warning log |

---

## Summary of All Files

| File | Status | Purpose |
|---|---|---|
| `.env` | MODIFY | Add `BATCH_SIZE=5` |
| `Resumes/` | NEW folder | Input PDF drop zone |
| `ProcessedResumes/` | NEW folder | Successfully ingested files |
| `QuarantinedFiles/` | NEW folder | Failed files + error reports |
| `src/batch/batchIngest.ts` | NEW | CLI entry point |
| `src/batch/BatchOrchestrator.ts` | NEW | Main processing loop with prompt integration |
| `src/batch/BatchFolderManager.ts` | NEW | File system operations |
| `src/batch/BatchFileValidator.ts` | NEW | Pre-processing validations |
| `src/batch/BatchPromptHandler.ts` | **NEW** | **Interactive yes/no prompt between batches** |
| `src/batch/BatchLogger.ts` | NEW | Batch-level structured logging |
| `package.json` | MODIFY | Add `batch:ingest` npm script |
| All existing `src/ingestion/` files | NO CHANGE | Reused as-is |
| All existing `src/config/` files | NO CHANGE | Reused as-is |

---

> **No new npm packages are needed.** The utility uses only:
> - Node.js built-ins: `fs`, `path`, `readline` (for the interactive prompt)
> - Already installed: `winston`, `dotenv`, `mongodb`
> - Already in the codebase: `initializeConfig`, `connectMongoDB`, `ResumeIngestionService`
